README
SARSCOV2 Variant Calling Pipeline for Nanopore Data
based on CDC Nanopore SARSCOV2 protocol developed by Clint Paden 
jonathan.jacobs@qiagen.com
QIAGEN Digital Insights
31-MAR-2020

Background
This is a simple qc, trim, map, variant calling workflow for SARSCOV2. This assumes the protocol developed by Clint Paden @ CDC was used, and includes primer sequences for his protocol, and the sequencing was done on an ONT MinION platform. The bioinformatics protocol is very close to what CDC (Clint Paden) created, with the important differences being that the QC and mapping implemented is the version of minimap2/racon that is included with CLC Genomics Workbench - and not Medaka. The variant calling is done with CLC Fixed Ploidy Variant Caller, with settings that are "inspired by" those in Medaka, but care should be taken in evaluating variants or quasispecies results. Also, position specific primer trimming is included as a post-mapping step, similar to Clint's nanopore protocol. 

Additional details in parameters text file. 

Requirements
CLC Genomics Workbench v20 or later with Long Read Analysis plugin installed. Will not work with earlier versions of CLC.

CHANGE LOG
0.1
- Initial Version


Archive Contents
./CDC Protocol ONT Amplicon.pdf
PDF of workflow structure.

./CDC ONT Protocol.zip
Full CLC files for import into CLC. Use File>Import>Zip in CLC to create a folder with all the raw files. Same content as the installer, but allows for modifications and editing of workflow itself.

./CDC Protocol ONT Amplicon-0.1.cpw
CLC workflow installer file, includes all references and adapter sequences. 

./README.txt
This file.

./CDC Protocol ONT Amplicon.txt
parameters set for all steps in the workflow.