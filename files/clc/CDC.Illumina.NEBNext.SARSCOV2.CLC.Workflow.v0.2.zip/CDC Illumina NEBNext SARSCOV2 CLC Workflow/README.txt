README
SARSCOV2 Variant Calling Pipeline
jonathan.jacobs@qiagen.com
QIAGEN Digital Insights
31-MAR-2020

Background
This is a simple qc, trim, map, variant calling workflow for SARSCOV2. This assumes the NEBNext library kit was used, and includes adapter sequences for this kit. and the sequencing was done on an Illumina platform. The bioinformatics protocol is very close to what CDC (Clint Paden) created, but has a few differences in qc/trimming used and variant calling requirements. 

QC/trimming - NEBNext adapters from CDC protocol are included, and trimmed. In addition, the workflow trims based on read-through, quality of Q30, has a 1 ambigous base limit, and trims 3' polyG from potential Illumina 2-color platforms. Minimum read length is 75.

Mapping - Reference(MN908947.3 (Genome)), Masking mode None, 
Match score 1, Mismatch cost 2, Cost of insertions and deletions: Linear gap cost, Insertion cost 3, Deletion cost 3, 
Insertion open cost 6, Insertion extend cost 1, Deletion open cost 6, Deletion extend cost 1, Length fraction 0.5, Similarity fraction 0.8.

Variant Calling - Low Frequency Variant Detection with Required significance 1.0%, Ignore positions with coverage above 100000, Restrict calling to target regions , Ignore broken pairs true, Ignore non-specific matches Reads, Minimum read length 20, Minimum coverage 100, Minimum count 2, Minimum frequency 1.0%, Base quality filter true, Neighborhood radius 5bp, Minimum central quality q30, Minimum neighborhood quality q15, Relative read direction filter true, Significance 1.0%.

Requirements
CLC Genomics Workbench v20 or later. May work with earlier versions of CLC, but has not been tested. 

CHANGE LOG
0.2
- Added Consensus sequence as output with IUPAC ambiguity codes
- Added annotations to consensus output that is from conflicts with reference.
- Reduced low frequency variant calling to 100x coverage, and 1 base for minimum cut offs for minor variants

0.1
- Initial Version


Archive Contents
./CDC NEBnext Illumina SARSCOV2.pdf
PDF of workflow structure.

./CDC NEBnext Illumina SARSCOV2.zip
Full CLC files for import into CLC. Use File>Import>Zip in CLC to create a folder with all the raw files. Same content as the installer, but allows for modifications and editing of workflow itself.

./CDC NEBnext Illumina SARSCOV2-0.1.cpw
CLC workflow installer file, includes all references and adapter sequences. 

./README.txt
This file.

./Parameters CDC NEBnext Illumina SARSCOV2.txt
parameters set for all steps in the workflow.