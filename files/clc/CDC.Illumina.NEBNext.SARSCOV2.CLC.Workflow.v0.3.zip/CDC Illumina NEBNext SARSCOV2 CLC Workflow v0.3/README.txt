README
CDC Illumina NEBNext SARSCOV2 CLC Workflow v0.3
jonathan.jacobs@qiagen.com
QIAGEN Digital Insights
2-APR-2020

FOR RESEARCH USE ONLY.

QIAGEN products shown here are intended for molecular biology applications. These products are not intended for the diagnosis, prevention or treatment of a disease. For up-to-date licensing information and product-specific disclaimers, see the respective QIAGEN kit handbook or user manual. QIAGEN kit handbooks and user manuals are available at www.qiagen.com or can be requested from QIAGEN Technical Services or your local distributor.

Background
This is a simple qc, trim, map, variant calling workflow for SARSCOV2. This assumes the CDC Procotol for Illumina shotgun sequencing (metagenomics) approach, with the NEBNext library kit was used (the appropriate adapter sequences for this kit are included). The bioinformatics protocol is very close to what CDC (Clint Paden) created, but has a few differences in qc/trimming used and variant calling requirements. 

All parameters and settings are outlined in the "CDC NEBnext Illumina SARSCOV2.txt" file included in this workflow.

NOTE: This workflow should result in high quality consensus sequences. It may also, however, report far more variants than expected. These are likely minor variants stemming from quasispecies present in an individual sample, and may not be reflected in the resulting consensus sequence the workflow outputs, but would be reflected in the resulting variant tracks (both NT and AA tracks, which can be output as vcf if needed). 

Requirements
CLC Genomics Workbench v20 or later. May work with earlier versions of CLC, but has not been tested. 

CHANGE LOG
0.3
- Updated QC&trimming to q20 (0.01) and maximum 2 ambigous reads.
- Updated variant calling settings. Specifically, 
	- coverage and count filter settings to a Minimum coverage 100, Minimum count 10, and Minimum frequency 1%.
	- base quality filter settings with a Neighborhood radius 5, Minimum central quality q30, Minimum neighborhood quality	q20.
	- read direction filter settings to include Direction frequency filter 5% and Relative read direction filter 1% significance.
	- remove pyro-error variants is active and variants in homopolymer regions with minimum length 3 and a  frequency below	80% will be filtered.


0.2
- Added Consensus sequence as output with IUPAC ambiguity codes
- Added annotations to consensus output that is from conflicts with reference.
- Reduced low frequency variant calling to 100x coverage, and 1 base for minimum cut offs for minor variants

0.1
- Initial Version


Archive Contents
./CDC NEBnext Illumina SARSCOV2.pdf
PDF of workflow structure.

./CDC NEBnext Illumina SARSCOV2 v0.3.zip
Full CLC files for import into CLC. Use File>Import>Zip in CLC to create a folder with all the raw files. Same content as the installer, but allows for modifications and editing of workflow itself.

./README.txt
This file.

./CDC NEBnext Illumina SARSCOV2.txt
parameters set for all steps in the workflow.