README
ARTICv3 Nanopore SARSCOV2 CLC Workflow v0.2
jonathan.jacobs@qiagen.com
QIAGEN Digital Insights
2-APR-2020

FOR RESEARCH USE ONLY.

QIAGEN products shown here are intended for molecular biology applications. These products are not intended for the diagnosis, prevention or treatment of a disease. For up-to-date licensing information and product-specific disclaimers, see the respective QIAGEN kit handbook or user manual. QIAGEN kit handbooks and user manuals are available at www.qiagen.com or can be requested from QIAGEN Technical Services or your local distributor.

Background
This is a simple qc, trim, map, variant calling workflow for SARSCOV2 using the ARTIC Nanopore protocol. The bioinformatics pipeline is modeled after the ARTIC pipeline implemented by Josh Quick, only implemented using CLC tools. The archive includes the workflow and is bundled with ONT adapters, and the Artic primers, and assumes sequencing was done on an ONT MinION platform. Differences from the CLC workflow results compared to the FOSS pipeline that uses ivar are likely, but may or may not be significant. Please contact me if there's any major issue with this pipeline that needs to be fixed. Note that the QC and mapping implemented is the version of minimap2/racon that is included with CLC Genomics Workbench - and not Medaka. The variant calling is done with CLC Fixed Ploidy Variant Caller, with settings that are "inspired by" those in Medaka, but care should be taken in evaluating variants or quasispecies results. Also, position specific primer trimming is included as a post-mapping step, similar to Josh Quick's pipeline. 

Additional details in parameters text file. 

Requirements
CLC Genomics Workbench v20 or later with Long Read Analysis plugin installed. Will not work with earlier versions of CLC.

CHANGE LOG
0.2
- Fixed bug in formating of ARTICv3 primer bed file that was preventing them from being trimmed appropriately.
- Updated to include adapter trimming specifically for ONT 1D Ligation adapter kit, and for trimming reads to 400 - 700bp (min/max), which is specified by ARTIC protocol.
- Updated variant calling settings. Specifically, 
	- removed base quality filter, since error correction step of RACON does not output quality scores
	- updated coverage and count filter settings to a Minimum coverage 100, Minimum count 20,and Minimum frequency 20%.
	- remove pyro-error variants is active and variants in homopolymer regions with minimum length 3 and a  frequency below	80% will be filtered.

0.1
- Initial Version


Archive Contents
./CDC Protocol ONT Amplicon.pdf
PDF of workflow structure.

./CDC ONT Protocol.zip
Full CLC files for import into CLC. Use File>Import>Zip in CLC to create a folder with all the raw files. Same content as the installer, but allows for modifications and editing of workflow itself.

./CDC Protocol ONT Amplicon-0.1.cpw
CLC workflow installer file, includes all references and adapter sequences. 

./README.txt
This file.

./CDC Protocol ONT Amplicon.txt
parameters set for all steps in the workflow.