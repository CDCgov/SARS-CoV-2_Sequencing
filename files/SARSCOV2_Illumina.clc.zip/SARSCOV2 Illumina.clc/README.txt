// README
MAR 20, 2020
Jonathan Jacobs
@bioinformer on Twitter

0. CLC Genomics Workbench v20.0.3
This software is being provide for free from QIAGEN Digital Insights until June 15th, 2020. Details here: https://go.qiagen.com/QDI-COVID19

1. PERFORMANCE & Assumptions
The workflow below has been run successfully with a 130M 1x150 PE read dataset on a laptop with 16GB RAM.  It took about 45 minutes. Everything else was much faster. 

The workflow I created in this zip archive assumes you have shotgun RNAseq data prepped with NexteraXT library prep kit. If you are using targeted sequencing, SISPA, Ion Torrent, or Oxford Nanopore data - alternative workflows would need to be created. It's not hard, but please contact me via Twitter (above) or LinkedIn if you have questions or need help. Happy to help. 


2. CONTENTS
This workflow includes mapping against a large collection of SARSCOV2 isolate genomes (provided by the user), mapping of non-SARSCOV2 reads to the human genome reference (provided by user), and read extraction/remapping of SARSCOV2 reads to a single isolate (NC_045512 is included with the workflow), variant calling, identification of nonsynonmous AA changes, creating a track list of relavent data for the isolates (variants, AA changes, etc), consensus sequence calling. The user must provide a list of SARSCOV2 references for the first step, and the human genome reference sequence. All parameters and inputs can be modified, and addtional tools could be added as needed (such as automatic import or export of results).

2.1 SARSCOV2 Illumina Workflow-0.1.cpw
Workflow installer file, to be installed for running in CLC Genomics Workbench v20.0.3, CLC Genomics Server, or CLC Genomics Cloud Engine. It may work on previous versions of CLC, but your mileage may vary. 

2.1.1 Installation
CLC Genomics Workbench
https://resources.qiagenbioinformatics.com/manuals/clcgenomicsworkbench/current/index.php?manual=Installing_workflow.html

CLC Genomics Server for distributed use
https://resources.qiagenbioinformatics.com/manuals/clcserver/current/admin/index.php?manual=Workflows.html

2.2 SARSCOV2 Illumina.clc
Raw workflow file for editing in CLC's workflow editor. To use this, open CLC Genomics Workbench, choose Import > Standard Import. Choose "Automatically Detect", and select a location in the naviagation view. 

2.3 PNG files
Two PNG files are provided that show the workflow, and a track view of variants, etc.